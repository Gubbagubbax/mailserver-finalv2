package com.example.mailserver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EmailService {

    @Autowired
    private EmailRepository emailRepository;

    public Email createEmail(Email email) {
        email.setTimestamp(LocalDateTime.now());
        return emailRepository.save(email);
    }

    public List<Email> getAllEmails() {
        return emailRepository.findAll();
    }

    public void deleteEmail(Long id) {
        emailRepository.deleteById(id);
    }
}


